#!/bin/bash

LOG_FOLDER="/usr/routebox/logs/realtime"
LOG_FILE="$LOG_FOLDER/ping.log"
MAX_BATCH_SIZE=50 # max batch size
BATCH_PERCENT=25  # max batch size percent
INTERVAL=10       # base intervals
my_ip=""
target_ips=()            # all target IPs (exclude node self)
shuffled_ips=()          # shuffled IPs
current_index=0          # current batch start index
batch_size=0             # actual batch size

declare -a batch_targets # current batch target IPS

all_ips=("100.0.1.145" "100.0.1.149" "100.0.1.153" "100.0.1.157" "100.0.1.161" "100.0.1.165" "100.0.1.169" "100.0.1.173" "100.0.1.177" "100.0.1.181" "100.0.1.185" "100.0.1.189" "100.0.1.193" "100.0.1.197" "100.0.1.201" "100.0.1.205" "100.0.1.209" "100.0.1.213" "100.0.1.217" "100.0.1.221" "100.0.1.225" "100.0.1.229" "100.0.1.233" "100.0.1.237" "100.0.1.241" "100.0.1.245" "100.0.1.249" "100.0.1.253" "100.0.2.1" "100.0.2.5" "100.0.2.9" "100.0.2.13" "100.0.2.17" "100.0.2.21" "100.0.2.25" "100.0.2.29" "100.0.2.33" "100.0.2.37" "100.0.2.41" "100.0.2.45" "100.0.2.49" "100.0.2.53" "100.0.2.57" "100.0.2.61" "100.0.2.65" "100.0.2.69" "100.0.2.73" "100.0.2.77" "100.0.2.81" "100.0.2.85" "100.0.1.146" "100.0.1.150" "100.0.1.154" "100.0.1.158" "100.0.1.162" "100.0.1.166" "100.0.1.170" "100.0.1.174" "100.0.1.178" "100.0.1.182" "100.0.1.186" "100.0.1.190" "100.0.1.194" "100.0.1.198" "100.0.1.202" "100.0.1.206" "100.0.1.210" "100.0.1.214" "100.0.1.218" "100.0.1.222" "100.0.1.226" "100.0.1.230" "100.0.1.234" "100.0.1.238" "100.0.1.242" "100.0.1.246" "100.0.1.250" "100.0.1.254" "100.0.2.2" "100.0.2.6" "100.0.2.10" "100.0.2.14" "100.0.2.18" "100.0.2.22" "100.0.2.26" "100.0.2.30" "100.0.2.34" "100.0.2.38" "100.0.2.42" "100.0.2.46" "100.0.2.50" "100.0.2.54" "100.0.2.58" "100.0.2.62" "100.0.2.66" "100.0.2.70" "100.0.2.74" "100.0.2.78" "100.0.2.82" "100.0.2.86")

# initialize self-ip and target IPs
init_ips() {
    local_ips=$(ip -4 -o addr show up | awk '!/lo:/ && !/127\./ {split($4, a, "/"); print a[1]}' | sort -u)
    for local_ip in $local_ips; do
        for i in "${!all_ips[@]}"; do
            if [[ "${all_ips[$i]}" == "$local_ip" ]]; then
                my_ip="$local_ip"
                target_ips=("${all_ips[@]:0:$i}" "${all_ips[@]:$((i + 1))}") # exclude node self
                return 0
            fi
        done
    done
    echo "[Error]: The local IP was not matched in all_ips" >&2
    return 1
}

# initialize batch info
init_batch() {
    total_nodes=${#target_ips[@]}
    batch_size=$((total_nodes * BATCH_PERCENT / 100)) # calculate batch size
    [ $batch_size -gt $MAX_BATCH_SIZE ] && batch_size=$MAX_BATCH_SIZE
    [ $batch_size -lt 1 ] && batch_size=1 # at least 1 target
}

# shuffle ips
shuffle_ips() {
    shuffled_ips=($(printf "%s\n" "${target_ips[@]}" | shuf))
}

# get current batch targets
get_batch_targets() {
    batch_targets=()
    local count=0
    local index=$current_index
    while [ $count -lt $batch_size ]; do
        batch_targets+=("${shuffled_ips[$index]}")
        index=$(((index + 1) % ${#shuffled_ips[@]}))
        count=$((count + 1))
        [ $index -eq $current_index ] && break
    done
    current_index=$index
}

# log
log() {
    echo "$(date +%s)|$1" >>"$LOG_FILE"
}

# init
if ! init_ips; then
    echo "Failed to initialize IPs. Exit..." >&2
    exit 1
fi
init_batch
shuffle_ips
# keep running
while true; do
    start_time=$(date +%s)
    get_batch_targets # get current batch targets
    log "!BatchTargets|$(echo ${batch_targets[@]} | tr ' ' ',')"
    # ping each target
    for ip in "${batch_targets[@]}"; do
        result=$(ping -c 1 -W 10 -I "$my_ip" "$ip" 2>&1) # timeout 10s
        if echo "$result" | grep -q "time="; then
            delay=$(echo "$result" | awk -F"time=" '/time=/ {print $2}' | awk '{print $1}') # get delay
            log "$ip|$delay"
        else
            log "$ip|10000"
        fi
    done
    elapsed=$(($(date +%s) - start_time))
    wait_time=$((INTERVAL - elapsed))
    if [ $wait_time -gt 0 ]; then # wait for next batch
        sleep $wait_time
    fi
done